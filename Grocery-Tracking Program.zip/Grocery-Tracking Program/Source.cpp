#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <cmath>
using namespace std;

void displayMenu();
map<string, int> readFile(const string& fileName);

void itemCount(int);
void itemFrequency(map<string, int>);
void itemHistogram(map<string, int>);

int main() {

    string file = "CS210_Project_Three_Input_File.txt";
    map<string, int> groceryMap = readFile(file);
    displayMenu();

    // add code to get user input
    int userOption;
    string inputString;

    do {
        cin >> userOption;
        switch (userOption) { // created switch statement for all functions
        case 1:
            cout << "Enter item you want number for: ";
            int numItems;
            cin >> inputString;
            numItems = groceryMap[inputString];
            itemCount(numItems);
            break;

        case 2:
            itemFrequency(groceryMap);
            break;
        case 3:
            itemHistogram(groceryMap);
            break;
        case 4:
            break;
        }

    } while (userOption != 4);

    return 0;



}

void itemHistogram(map<string, int> groceryMap) { // called histogram function
    for (auto& pair : groceryMap) {
        cout << pair.first;
        for (int i = 0; i < pair.second; i++) {
            cout << "*";
        }
        cout << endl;
    }
}

void itemFrequency(map<string, int> groceryMap) { // called item frequency function
    //open file in write mode
    ofstream outFile("frequency.dat");

    for (auto& pair : groceryMap) {
        cout << "Frequency of items purchased " << pair.first << " " << pair.second << endl;
        outFile << "Frequency of items purchased " << pair.first << " " << pair.second << endl;
    }
    // close the file
    outFile.close();

}

void itemCount(int x) { // called item count
    using namespace std;
    cout << "number of items " << x << endl;
}

void displayMenu() /* displays the grocer menu*/
{
    cout << "1.  Item Count" << endl;
    cout << "2. 	Item Pruchased Frequency" << endl;
    cout << "3.  Item Histogram" << endl;
    cout << "4.  Exit Program" << endl;

    cout << "Please make your selection (1-4): ";


}

map<string, int> readFile(const string& fileName)
{
    ifstream list(fileName);
    string line;
    map<string, int> itemCount;
    if (list.is_open())
    {
        while (getline(list, line))
        {
            if (itemCount.count(line) == 0)
            {
                // need to add Line to the map with a key of zero
                itemCount.insert(std::pair<string, int>(line, 1));
            }
            else
            {
                // we don't need to add, we can just increment
                itemCount[line]++;
            }
        }

    }
    return itemCount;
}